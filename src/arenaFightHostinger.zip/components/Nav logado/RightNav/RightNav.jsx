import React from 'react';
import { Ul } from "./styles";
import aftcount from '../../../assets/aftcount.png'
import { useNavigate } from 'react-router-dom'

const RightNav = ({ open }) => {

  const navigate = useNavigate()
  const sendTo = (path) => {
    navigate(path)
  }

  return (
    <Ul open={open}>
      <li><img src={aftcount} alt=""/></li>
      <li >Metamask Address</li>
      <li onClick={() => sendTo('/lutador')} className="desktopnav">Fighters</li>
      <li onClick={() => sendTo('/my-gym')} className="desktopnav">My Gym</li>
      <li onClick={() => sendTo('/play')} className="desktopnav last">Play Now</li>
      
    </Ul>
  )
}

export default RightNav